using System;

namespace ConsoleApp1

public class Program

{
	static void Main(string[] args)
	{
		List<string> listaFrutas = new List<string>();
		string entrada;
		
		Console.WriteLine("Entre com a lista conforme manual do sistema:")/
		entrada = Console.Readline();

		string[] strArray = entrada.Split(';');
		
		foreach (string str in strrArray)
		{
			string fruta = str.ToLower();
			string primeiraLetra = fruta.Substring(0, 1).ToUpper();
			fruta = primeiraLetra
				+ fruta.Substring(1,fruta.Length-1);
			if (!listaFrutas.Contains(fruta))
				listaFrutas.add(fruta);
		}

		Console.WriteLine("Resposta:"+Environment.NewLine);
		foreach(string fruta in listaFrutas)
			Console.WriteLine(fruta);
	}
}