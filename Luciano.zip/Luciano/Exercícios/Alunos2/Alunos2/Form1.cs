namespace Alunos2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Aluno aluno = new Aluno();
            aluno.Nome = Convert.ToString(textBox1.Text);
            
            aluno.Nota1 = Convert.ToDouble(textBox2.Text);
            aluno.Nota2 = Convert.ToDouble(textBox3.Text);
            aluno.Nota3 = Convert.ToDouble(textBox4.Text);  
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        private void label5_Click(object sender, EventArgs e)
        {
            
            

        }
    }
}