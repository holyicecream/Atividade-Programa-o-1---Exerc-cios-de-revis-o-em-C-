﻿using System;

class Program
{
    static void Main(string[] args)
    {

        Console.Write("Digite o número de convidados do noivo: ");
        int numConvidadosNoivo = int.Parse(Console.ReadLine());

        Console.Write("Digite o número de convidados da noiva: ");
        int numConvidadosNoiva = int.Parse(Console.ReadLine());

        Console.Write("Digite o número de convidados presentes do noivo: ");
        int numPresentesNoivo = int.Parse(Console.ReadLine());

        Console.Write("Digite o número de convidados presentes da noiva: ");
        int numPresentesNoiva = int.Parse(Console.ReadLine());

        if (numConvidadosNoivo > numPresentesNoivo)
        {
            Console.WriteLine("O noivo esperava mais convidados do que o número de presentes.");
        }
        else if (numConvidadosNoivo == numPresentesNoivo)
        {
            Console.WriteLine("O número de convidados do noivo era igual ao número de presentes.");
        }
        else
        {
            Console.WriteLine("O noivo teve menos convidados do que o número de presentes.");
        }

        if (numConvidadosNoiva > numPresentesNoiva)
        {
            Console.WriteLine("A noiva esperava mais convidados do que o número de presentes.");
        }
    }
}