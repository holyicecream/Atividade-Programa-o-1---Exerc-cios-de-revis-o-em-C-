﻿using System;

class Program
{
    static void Main()
    {
        string[] convidados = new string[4];
        convidados[0] = "João";
        convidados[1] = "Maria";
        convidados[2] = "Pedro";
        convidados[3] = "Ana";

        Console.WriteLine("Lista de convidados:");
        foreach (string convidado in convidados)
        {
            Console.WriteLine(convidado);
        }

        Console.WriteLine("Tamanho da lista: " + convidados.Length);
    }
}