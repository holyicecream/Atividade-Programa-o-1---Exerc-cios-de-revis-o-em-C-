﻿using System;
using System.Collections.Generic;

public class Exerc2A
{
    public static void Main()
    {
        List<string> listaConvidados = new List<string>();

        Console.WriteLine("Digite os nomes dos convidados (digite '.' para terminar):");
        string nomeConvidado = Console.ReadLine();
        while (nomeConvidado != ".")
        {
            listaConvidados.Add(nomeConvidado);
            nomeConvidado = Console.ReadLine();
        }

        Console.WriteLine("Lista de Convidados:");
        foreach (string convidado in listaConvidados)
        {
            Console.WriteLine(convidado);
        }
    }
}