﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projetoAlunos
{
    public class Aluno
    {
        public Aluno(string Nome, int Matricula)
        {
            this.Nome = Nome;
            this.Matricula = Matricula;
        }

        public int Matricula { get; private set; }
        public string Nome { get; set; }

        public double Nota1 { get; set; }
        public double Nota2 { get; set; }
        public double Nota3 { get; set; }
        public double MediaFinal { get; private set; }

        public bool IsAprovado { get; private set; }


    }
}
