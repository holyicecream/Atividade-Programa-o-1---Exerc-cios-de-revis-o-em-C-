

namespace projetoAlunos

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_Cadastrar_Click(object sender, EventArgs e)
        {
            Aluno aluno = Aluno();
            aluno.Nome = textBox_Nome.Text;
            aluno.Nota1 = Convert.ToDouble(textBox_Nota1.Text);
            aluno.Nota2 = Convert.ToDouble(textBox_Nota2.Text);
            aluno.Nota3 = Convert.ToDouble(textBox_Nota3.Text);

            
                }

    }
}